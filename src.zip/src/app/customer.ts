export class Customer{
    name: string = "";
    code: number = 0;
}