import { Component } from '@angular/core';

@Component({
  selector: 'app-mailing',
  standalone: true,
  imports: [],
  templateUrl: './mailing.component.html',
  styleUrl: './mailing.component.css'
})
export class MailingComponent {

}
