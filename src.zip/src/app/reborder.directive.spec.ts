import { ReborderDirective } from './reborder.directive';

describe('ReborderDirective', () => {
  it('should create an instance', () => {
    const directive = new ReborderDirective();
    expect(directive).toBeTruthy();
  });
});
